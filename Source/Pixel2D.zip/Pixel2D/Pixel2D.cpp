// Copyright Epic Games, Inc. All Rights Reserved.

#include "Pixel2D.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Pixel2D, "Pixel2D" );
 