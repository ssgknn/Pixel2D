// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "PlayerStatsData.generated.h"

/**
 * 
 */
UCLASS()
class PIXEL2D_API UPlayerStatsData : public UObject
{
	GENERATED_BODY()
	
};
